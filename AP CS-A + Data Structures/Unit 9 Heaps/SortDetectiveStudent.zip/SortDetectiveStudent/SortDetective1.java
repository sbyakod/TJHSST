import edu.neu.ccs.*;
import edu.neu.ccs.gui.*;
import edu.neu.ccs.util.*;
import edu.neu.ccs.filter.*;
   
public class SortDetective1
{
   public static void main(String[] args)
   {
      JPTFrame.createQuickJPTFrame("Sort Detective", new SortDetective());
   }
}